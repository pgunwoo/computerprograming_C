#include <stdio.h>
#include <math.h>
int main(void)
{
	int a, b, c, d;
	scanf("%d %d %d %d", &a, &b, &c, &d);

	double average = (a + b + c + d) / 4.0;
	printf("������ : %f\n", average);

	double g = pow(a*b*c*d, 0.25);
	printf("������� : %f\n", g);

	return 0;
}