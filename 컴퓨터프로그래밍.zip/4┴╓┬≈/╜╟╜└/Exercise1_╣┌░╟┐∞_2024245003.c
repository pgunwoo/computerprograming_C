#include <stdio.h>
int main(void)
{
	int year, month, day, hour, min;
	scanf("%d/%d/%d %d:%d", &year, &month, &day, &hour, &min);

	printf("%d�� %d�� %d�� %d�� %d��", year, month, day, hour, min);

	return 0;
}