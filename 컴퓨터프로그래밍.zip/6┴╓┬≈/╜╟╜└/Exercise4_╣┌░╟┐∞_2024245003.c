#include <stdio.h>
int main(void)
{
	int n, sum=0;
	scanf("%d", &n);
	while (1)
	{
		sum += 1;
		printf("%4d", sum);
		if (sum % 8 == 0) {
			printf("\n");
		}
		if (sum == n) {
			goto goodBye;
		}
	}
	goodBye: printf("\nGood Bye!");
	return 0;
}