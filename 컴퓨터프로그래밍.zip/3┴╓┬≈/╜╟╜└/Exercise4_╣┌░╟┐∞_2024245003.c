#include <stdio.h>
int main(void)
{
	int a, b;
	printf("�� ������ �Է��Ͻÿ� : ");
	scanf("%d %d", &a, &b);

	printf("AND : %d\n", a & b);
	printf("OR : %d\n", a | b);
	printf("XOR : %d\n", a ^ b);
	printf("NOT a : %d, b : %d\n", ~a, ~b);

	return 0;
}