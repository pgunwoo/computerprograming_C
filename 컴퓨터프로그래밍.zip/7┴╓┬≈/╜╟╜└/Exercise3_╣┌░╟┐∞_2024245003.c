#include <stdio.h>

int fibonachi(int n);

int main(void)
{
	int n;
	scanf("%d", &n);

	printf("%d", fibonachi(n));
	return 0;
}

int fibonachi(int n)
{
	if (n == 1)
		return 1;
	if (n == 0)
		return 0;
	return fibonachi(n - 2) + fibonachi(n - 1);
}