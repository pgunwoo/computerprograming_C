#include <stdio.h>

struct complex
{
	double real;
	double imag;
};
int main(void)
{
	struct complex x = { 1.0, 2.0 };
	struct complex y = { 2.0, -3.0 };
	struct complex m;

	m.real = (x.real * y.real + x.imag * y.imag) / (y.real * y.real + y.imag * y.imag);
	m.imag = (x.imag * y.real - x.real * y.imag) / (y.real * y.real + y.imag * y.imag);

	printf("���Ҽ� ������ ��� = %.2lf + %.2lf i", m.real, m.imag);

	return 0;
}