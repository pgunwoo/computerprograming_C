#include <stdio.h>
int main(void)
{
	char s[1000000];
	gets(s);
	int i = 0, cnt=0;
	while (s[i] != '\0')
	{
		if (s[i] == ' ')
			cnt += 1;
		i++;
	}
	printf("%d", cnt + 1);
	return 0;
}