#include <stdio.h>
int main(void)
{
	char s[1000]="0";
	int n;

	gets(s);
	scanf("%d", &n);
	printf("%c", s[n-1]);

	return 0;
}