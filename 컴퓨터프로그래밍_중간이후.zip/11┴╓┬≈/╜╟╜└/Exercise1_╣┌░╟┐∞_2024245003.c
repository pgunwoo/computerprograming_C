#include <stdio.h>
int main(void)
{
	int n[10];
	int max, num;
	for (int i = 0; i < 9; i++)
	{
		scanf("%d", &n[i]);
	}
	max = n[0];
	for (int j = 0; j < 9; j++)
	{
		if (max < n[j])
		{
			max = n[j];
			num = j+1;
		}
	}
	printf("�ִ� : %d \n%d��° ��", max, num);

	return 0;
}