#include <stdio.h>
int main(void)
{
	int i, j, x, y, n, m, k, sum = 0;
	int a, b;
	int num[300][300] = { {0,}, {0, } };

	scanf("%d %d", &n, &m);

	for (a = 0; a < n; a++)
	{
		for (b = 0; b < m; b++)
		{
			scanf("%d", &num[a][b]);
		}
	}

	scanf("%d", &k);

	for (int c = 0; c < k; c++)
	{
		scanf("%d %d %d %d", &i, &j, &x, &y);
		for (a = i - 1; a < x; a++)
		{
			for (b = j-1; b < y; b++)
			{
				sum += num[a][b];
			}
		}

		printf("%d\n", sum);
		sum = 0;
	}
	

	return 0;
}