#include <stdio.h>
int main(void)
{
	int n, a=2, num;
	scanf("%d", &n);
	
	while (1)
	{
		if (n % a == 0)
		{
			num = n /= a;
			printf("%d\n", a);
			if (num == 1)
			{
				break;
			}
		}				
		else
		{
			a+=1;
		}		
	}
}
