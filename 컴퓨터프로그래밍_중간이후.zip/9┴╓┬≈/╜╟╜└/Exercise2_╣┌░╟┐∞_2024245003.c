#include <stdio.h>
int main(void)
{
	int a, b, v, sum=0,i=1;
	scanf("%d %d %d", &a, &b, &v);

	while (1)
	{
		sum += a;
		if (sum >= v) 
		{
			printf("%d", i);
			break;
		}
		sum -= b;
		i++;
	}
}