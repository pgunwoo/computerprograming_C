#include <stdio.h>
int main(void)
{
	int school=0, student=0, apple=0, sum=0;
	scanf("%d", &school);
	for (int i = 1; i <= school; i++)
	{
		scanf("%d %d", &student, &apple);
		sum += apple % student;
	}
	printf("%d", sum);
	return 0;
}