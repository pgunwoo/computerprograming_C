#include <stdio.h>
int main(void)
{
	int n, k;
	scanf("%d", &n);
	for (int i = 1; i <= n; i++)
	{
		if (n == 1)
		{
			printf("*");
		}
		else
		{
			for (int i = 1; i <= n; i+=2)
			{
				printf("* ");
			}
			printf("\n");
			for (int i = 1; i <= n / 2; i++)
			{
				printf(" *");
			}
			printf("\n");
		}
		
	}

	return 0;
}