#include <stdio.h>

int x4_car(int x1, int x2, int x3);
int y4_car(int y1, int y2, int y3);

int main(void)
{
	int x1, y1, x2, y2, x3, y3,x4,y4;
	scanf("%d %d", &x1, &y1);
	scanf("%d %d", &x2, &y2);
	scanf("%d %d", &x3, &y3);

	x4 = x4_car(x1, x2, x3);
	y4 = y4_car(y1, y2, y3);

	printf("%d %d", x4, y4);
	
	return 0;
}

int x4_car(int x1, int x2, int x3) 
{
	if (x1 == x2)
	{
		return x3;
	}
	else if (x2 == x3)
	{
		return x1;
	}
	else if (x1 == x3)
	{
		return x2;
	}
}

int y4_car(int y1, int y2, int y3)
{
	if (y1 == y2)
	{
		return y3;
	}
	else if (y2 == y3)
	{
		return y1;
	}
	else if (y1 == y3)
	{
		return y2;
	}
}