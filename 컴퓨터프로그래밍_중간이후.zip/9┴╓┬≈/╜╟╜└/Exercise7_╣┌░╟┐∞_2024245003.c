#include <stdio.h>
int main(void)
{
	int a, b, c, result;
	scanf("%d %d %d", &a, &b, &c);

	if (a >= b)
	{
		if (a < c)
		{
			result = a;
		}
		else 
		{
			if (c >= b)
			{
				result = b;
			}
			else
			{
				result = c;
			}
		}
	}
	else if (b >= c)
	{
		if (b < a)
		{
			result = b;
		}
		else
		{
			if (a >= c)
			{
				result = a;
			}
			else
			{
				result = c;
			}
		}
	}
	else
	{
		if (c < b)
		{
			result = c;
		}
		else
		{
			if (b >=  a)
			{
				result = b;
			}
			else
			{
				result = a;
			}
		}
	}
	printf("%d", result);
	return 0;
}