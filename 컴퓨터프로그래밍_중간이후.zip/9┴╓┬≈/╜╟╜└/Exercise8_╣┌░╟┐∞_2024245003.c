#include <stdio.h>

int func(int n)
{
	if (n == 1)
		return 1;
	else
		return (n - 1) * 6 + func(n - 1);
}

int main(void)
{
	int num, x = 0;
	scanf("%d", &num);
	if (num == 1)
		x = 1;
	else
	{
		for (int i = 1; i <= num; i++)
		{
			if (func(i) >= num && func(i - 1) < num)
			{
				x = i;
				break;
			}
		}
	}
	printf("%d", x);
	return 0;
}