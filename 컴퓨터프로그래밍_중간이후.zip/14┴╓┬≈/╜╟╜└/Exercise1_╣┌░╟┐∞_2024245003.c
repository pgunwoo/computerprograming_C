#include <stdio.h>
#include <string.h>
int main()
{
	char s[40];
	char* p;

	printf("Input String : ");
	scanf("%s", s);

	p = s;

	printf("Revers String : ");
	for (int i = strlen(p) - 1; i >= 0; --i) {
		printf("%c", p[i]);
	}

	return 0;
}