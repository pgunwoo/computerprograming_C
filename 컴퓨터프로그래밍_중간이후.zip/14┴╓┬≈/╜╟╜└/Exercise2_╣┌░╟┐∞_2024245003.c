#include <stdio.h>
int main(void)
{
	char s[100] = { 0 };
	char* p;

	scanf("%s", s);

	p = s;

	for (int i = 97; i <= 122; i++) {
		int j = 0;
		while (p[j] != 0) {
			if (p[j] == (char)i)
				break;
			j++;
		}
		if (p[j] == (char)i)
			printf("%d ", j);
		else
			printf("-1 ");
	}

	return 0;
}