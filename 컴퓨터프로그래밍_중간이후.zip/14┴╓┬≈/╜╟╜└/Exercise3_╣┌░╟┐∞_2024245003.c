#include <stdio.h>
#include <string.h>
void reverse_string(char* start, char* end)
{
    while (end > start)
    {
        char temp = *start;
        *start = *end;
        *end = temp;
        start++;
        end--;
    }
}

int main(void)
{
    char str[101];
    char* ptr;

    printf("���ڿ��� �Է��ϼ���: ");
    fgets(str, sizeof(str), stdin);

    ptr = strchr(str, '#');

    if (ptr)
    {
        reverse_string(str, ptr - 1);
        printf("%.*s\n", (int)(ptr - str), str);
    }

    else
    {
        printf("%s\n", str);
    }

    return 0;
}