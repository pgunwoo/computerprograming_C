#include <stdio.h>

struct complex
{
    double real;
    double imag;
};

struct complex add(struct complex a, struct complex b)
{
    struct complex result;
    result.real = a.real + b.real;
    result.imag = a.imag + b.imag;
    return result;
}

struct complex sub(struct complex a, struct complex b)
{
    struct complex result;
    result.real = a.real - b.real;
    result.imag = a.imag - b.imag;
    return result;
}

struct complex mul(struct complex a, struct complex b)
{
    struct complex result;
    result.real = a.real * b.real - a.imag * b.imag;
    result.imag = a.real * b.imag + a.imag * b.real;
    return result;
}

struct complex div(struct complex a, struct complex b)
{
    struct complex result;
    double denominator = b.real * b.real + b.imag * b.imag;
    result.real = (a.real * b.real + a.imag * b.imag) / denominator;
    result.imag = (a.imag * b.real - a.real * b.imag) / denominator;
    return result;
}

int main(void)
{
    struct complex(*p[4])(struct complex a, struct complex b) = { add, sub, mul, div };
    int choice;
    struct complex num1, num2, result;

    printf("1. Add\n");
    printf("2. Subtract\n");
    printf("3. Multiply\n");
    printf("4. Divide\n");
    printf("Enter your choice: ");
    scanf("%d", &choice);

    printf("Enter real and imaginary parts of complex number: ");
    scanf("%lf %lf", &num1.real, &num1.imag);
    printf("Enter real and imaginary parts of complex number: ");
    scanf("%lf %lf", &num2.real, &num2.imag);

    if (choice >= 1 && choice <= 4)
    {
        result = (*p[choice - 1])(num1, num2);
        switch (choice)
        {
        case 1:
            printf("Result of addition: %.2lf + %.2lfi\n", result.real, result.imag);
            break;
        case 2:
            printf("Result of subtraction: %.2lf + %.2lfi\n", result.real, result.imag);
            break;
        case 3:
            printf("Result of multiplication: %.2lf + %.2lfi\n", result.real, result.imag);
            break;
        case 4:
            printf("Result of division: %.2lf + %.2lfi\n", result.real, result.imag);
            break;
        }
    }

    return 0;
}